define( ["qlik",  "jquery", "css!./datepicker.css"],
function (qlik) {
	return {
		initialProperties : {
			version : 1.0,
			variableValue : {},
			variableName : "",
		},
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		definition : {
			type : "items",
			component : "accordion",
			items : {
				settings : {
					uses : "settings",
				  	items : {
						variable : {
							type : "items",
							label : "Variable",
							items : {
								name : {
									ref : "variableName",
									label : "Name",
									type : "string",
									change : function(data) {
										//create variable - ignore errors
										qlik.currApp().variable.create(data.variableName);//creo la variabile currApp
										data.variableValue.qStringExpression = '=' + data.variableName;
									}
								},

							}
						}
					}
				}
			}
		},
		
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

		//"$element" è l'elemento HTML nel quale il metodo paint deve renderizzare l'estensione; "layout" sono i dati da visualizzare
		paint : function($element, layout) {//paint è il metodo per far vedere l'estensione (la disegna)
			var html = "", t = this;//creo variabile "html" e "t"
			
			//inserisco un bottone con id "datepicker" e classe "CalendarButton" la value è vuota;
			html += '<input type="button" class="CalendarButton" id="datepicker"  value="' +  layout.variableValue + '" >';
			
			//cerca tutti i "button" contenuti in "html" al click (qv-activate è simile al click)
			$element.html(html).find('button').on('qv-activate', function() {
			
				//creo la variabile "val" alla quale do come valore "this" al quale ho attaccato "alt" usando il .data()
				var val = $(this).data('alt') + '';
				
				//tramite il "setContenet" imopsto il valore della variabile currApp
				qlik.currApp(t).variable.setContent(layout.variableName, val);
				
			});
			
			//cerca tutti i "select" e "input" con tag "element" quando si ha un cambiamento ('change')
			$element.find('select, input').on('change', function() {
			
				var val = $(this).val() + '';//creata variabile "val" con valore di this; THIS è il find precedente
				//tramite il "setContenet" imopsto il valore della variabile currApp
				qlik.currApp(t).variable.setContent(layout.variableName, val);
			})
			$(function() {
   				$( "#datepicker" ).datepicker({
  					dateFormat: "dd/mm/yy"//dichiaro il formato della data
				});
 			});		
		}
	};
} );
